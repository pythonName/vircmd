在命令行cd到当前目录

然后执行chmod +x install.sh

再执行 ./install.sh 进行安装

最后 执行命令./vircmd -i /Users/xxx/xx.ipa -c 5 【-i 需要执行安装的ipa文件，-c 需要多开的个数】