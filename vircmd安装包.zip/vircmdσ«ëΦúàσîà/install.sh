#!/usr/bin/env bash

# 获取当前用户的 Library 目录
libraryDir="${HOME}/Library"

# 判断 Frameworks 文件夹是否存在，不存在则创建
frameworksDir="${libraryDir}/Frameworks"
if [ ! -d "${frameworksDir}" ]; then
    mkdir "${frameworksDir}"
fi

# 创建 vircmd 目录
vircmdDir="${frameworksDir}/vircmd"
mkdir -p "${vircmdDir}"

mv "$(dirname "${BASH_SOURCE[0]}")/default.yaml" "${vircmdDir}/"
mv "$(dirname "${BASH_SOURCE[0]}")/VirCommon.framework" "${vircmdDir}/"

# 给 vircmd 文件增加执行权限
chmod +x "vircmd"
